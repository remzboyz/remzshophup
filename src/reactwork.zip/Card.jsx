
import  profilepic from './assets/jack.jpg'

function Card(){
return(
    <div className="card">
        <img  className="card-image"src={profilepic}height="200px" width="200px" alt="profilepic"></img>
        <h2 className='card-title'>remz overlord</h2>
        <p className='card-text'> a student fom mciu and a basketball also enjoying playing video games </p>

    </div>
);
}


/*   APP COMPONENT      */
<div className='card'>
    <Avatar/>
    <div className='data'>
    <Intro/>
    <Skilllist/>

</div>
</div>

/* OTHER COMPONETS  */
function Avatar(){
    return(
    <img  className='avatar' src={spanishPizzaimg} alt='neva'/>
);
}


function Intro(){
    return(
        <div>
            <h1>jonas section</h1>

            <p>
                full stack developer
                1.	Load Balancing: This distributes incoming user traffic across multiple servers. If one server fails, the load balancer identifies the failure and redirects users to healthy servers, preventing downtime.
               2.	Auto-Scaling: This feature monitors system load in real-time
               . When it detects a traffic spike, it automatically "spins up" new servers to handle the load
                and "spins them down" when traffic drops to save money.

            </p>
        </div>
    );
}

function Skilllist(){
    return(
        <div className='skill-list'>
            <Skill  Skill ="rigo" emoji ="delielie" />
            <Skill  Skill= "jean"  emoji= "ricardo"/>

        </div>
    );
}


function Skill(props){

    return(
        <div className='skill'>
            <span>{props.Skill}</span>
            <span>{props.emoji}</span>

        </div>

    );

}




export default Card